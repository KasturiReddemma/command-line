var synonyms = require("synonyms");
 
console.log(synonyms("word"));
/* returns an object like this:
{
    n:['screen','cover','covert','concealment'],
    v:['screen','sieve','sort','test']
}
*/
synonyms("screen","v");

/* returns an array like this:
['screen','sieve','sort','test']
*/

//console.log(synonyms.dictionary);
// returns the whole dictionary