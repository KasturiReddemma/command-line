var unirest = require("unirest");

var req = unirest("GET", "https://wordsapiv1.p.rapidapi.com/words/hatchback/typeOf");

req.headers({
	"x-rapidapi-host": "wordsapiv1.p.rapidapi.com",
	"x-rapidapi-key": "b5087af3a35fbbfe94912d8e9b49c4afbc7209fcf84447068d8ee120e1daf8461023519820f5ee6f0c773ff64b129d5db16717880a92502811f65e08550bf03a9c34fdab0597dc39a100dca60ef6a727"
});


req.end(function (res) {
	if (res.error) throw new Error(res.error);

	console.log(res.body);
});