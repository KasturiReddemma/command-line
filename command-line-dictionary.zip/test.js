/*
var questions = [{
  type: 'input',
  name: 'name',
  message: "Enter any word to find details",
  
}]

inquirer.prompt(questions).then(answers => {
  console.log(`You entered word ${answers['name']}!`)
})

function getWordDefinition(data,callback)
{
	if(data)
	{
		
		var key = 'b972c7ca44dda72a5b482052b1f5e13470e01477f3fb97c85d5313b3c112627073481104fec2fb1a0cc9d84c2212474c0cbe7d8e59d7b95c7cb32a1133f778abd1857bf934ba06647fda4f59e878d164';
		//var url='https://fourtytwowords.herokuapp.com/words'+'/randomWord?api_key=b972c7ca44dda72a5b482052b1f5e13470e01477f3fb97c85d5313b3c112627073481104fec2fb1a0cc9d84c2212474c0cbe7d8e59d7b95c7cb32a1133f778abd1857bf934ba06647fda4f59e878d164';
		var url='https://fourtytwowords.herokuapp.com/word/'+data+'/definitions?api_key='+key;
		https.get(url, function(res){
			sleep(3000);
			var str = '';
			console.log('Response is '+res.statusCode);

			res.on('data', function (chunk) {
				   str += chunk;
			 });

			res.on('end', function () {
				 console.log(str);
			});

		});
	}
}

//setTimeout(getWordDefinition, 3000);
getWordDefinition('frame',function(err,content){
	if(err){
		console.log(err);
	}
	else
		console.log(content);	
	
})

/*
   https.get('https://fourtytwowords.herokuapp.com/words/randomWord?api_key=b972c7ca44dda72a5b482052b1f5e13470e01477f3fb97c85d5313b3c112627073481104fec2fb1a0cc9d84c2212474c0cbe7d8e59d7b95c7cb32a1133f778abd1857bf934ba06647fda4f59e878d164', function(res){
        var str = '';
        console.log('Response is '+res.statusCode);

        res.on('data', function (chunk) {
               str += chunk;
         });

        res.on('end', function () {
             console.log(str);
        });

  });
*/
function randomsort(a, b) { 
	return Math.random()>.5 ? -1 : 1;
}
var arrStr = 'your string';
var randomStr = arrStr.split('').sort(randomsort); 
console.log(randomStr.join('')); //"nigorts ruy" 