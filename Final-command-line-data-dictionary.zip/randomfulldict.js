var express = require('express');
var app = express();
const inquirer = require('inquirer');
var https = require('https');
var sleep = require('system-sleep');

var key = 'b972c7ca44dda72a5b482052b1f5e13470e01477f3fb97c85d5313b3c112627073481104fec2fb1a0cc9d84c2212474c0cbe7d8e59d7b95c7cb32a1133f778abd1857bf934ba06647fda4f59e878d164';
		  

	https.get('https://fourtytwowords.herokuapp.com/words/randomWord?api_key='+key, function(res){
        var str = '';
        //console.log('Response is '+res.statusCode);

        res.on('data', function (chunk) {
               str += chunk;
         });

        res.on('end', function () {
			var parsedstr = JSON.parse(str);
            /**call definitions api*/
			console.log(parsedstr.word);
			parsedstr = parsedstr.word;
		    var url='https://fourtytwowords.herokuapp.com/word/'+parsedstr+'/definitions?api_key='+key;
			https.get(url, function(res){
				sleep(3000);
				var str = '';
				/**if status code is not success,we assume word doesn't exists in our dictionary*/
				if(res.statusCode!==200)
				{
					/**prompt user to select one choice*/
					console.log('This word does not exists');
					var options = [{
					  type: 'input',
					  name: 'name',
					  message: "Select one option 1.Try again 2. Hint 3. Quit",
					  
					}]
					inquirer.prompt(options).then(answers => {
					  console.log(`You selected option ${answers['name']}`);
					    /**if user select Try again*/
						if(answers['name']==1)
						{
							//Allow user to try again
							getdetails(callback);
						}
						/**if user select Hint provide Synonyms of word and similar words*/
						else if(answers['name']==2)
						{														
							//var arrStr = 'your string';
							var randomStr = parsedstr.split('').sort(randomsort); 
				
							console.log('Hint:');
							console.log(synonyms(parsedstr));
							console.log('Similar words :'+randomStr.join('')+','+randomStr.join(''));
							/**Allow user to try again*/
							getdetails(callback);
						}
						/**if user select Quit display details and exit*/
						else if(answers['name']==3)
						{
							wd.getDef(parsedstr, "en", null, function(definition) {
								console.log(definition);
								console.log("synonyms :");
								console.log(synonyms(parsedstr));
							});
						}
					})
					
					
				}
				else{
					//console.log('Response is '+res.statusCode);

					res.on('data', function (chunk) {
						   str += chunk;
					 });
					/**call api to get examples of a word*/
					var url1='https://fourtytwowords.herokuapp.com/word/'+parsedstr+'/examples?api_key='+key; 
					https.get(url1, function(res1){
						sleep(3000);
						var str1 = '';
						//console.log('Response is '+res1.statusCode);
						if(res.statusCode==200)
						{
							/**call api to get antonyms and synonyms of a word*/
							var url2='https://fourtytwowords.herokuapp.com/word/'+parsedstr+'/relatedWords?api_key='+key;
							https.get(url2, function(res2){
								var str2 = '';
								res2.on('data', function (chunk) {
								   str2 += chunk;
								});
								res2.on('end', function () {
									console.log('================Antonym and Synonyms====================');
									console.log('==================================================');
									//console.log(str2);
									var parsedData = JSON.parse(str2);						
									console.log(parsedData);
								});
								
							});
						}
						res1.on('data', function (chunk) {
						   str1 += chunk;
						});
						res1.on('end', function () {
							console.log('==================Examples====================');
							console.log('==================================================');
							//console.log(str1);
							var parsedData = JSON.parse(str1);						
							console.log(parsedData);
						});
					});

					res.on('end', function () {
						console.log('=======================Definitions================');
						console.log('==================================================');
						//console.log(str);
						//var escapedJsonstring = str.split('\\').join('');
						var parsedData = JSON.parse(str);
						
						console.log(parsedData);
					});
				}
				

			});
        });

    });
